

<?php $__env->startSection('container'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="mt-3">
                    <h3 class="mt-3 text-center">Pesanan Saya</h3>
                </div>

                <div class="col-md-d p-5" >
                    <?php if($orders->isEmpty()): ?>
                        <p>Anda belum membuat pesanan apapun</p>
                    <?php else: ?>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card mt-3">
                            <div class="card-body">
                                <div class="card-text">
                                    <div class="">
                                        <h5 class="d-inline">Pesanan <?php echo e($index + 1); ?> : </h5>
                                        

                                        <div class="d-inline text-right">
                                            <button class="btn text-dark" style="background-color: #fafafa">
                                                <?php if($order->payment_status == 0): ?> 
                                                    <p>Menunggu Pembayaran</p>
                                                <?php elseif($order->payment_status == 1): ?>
                                                    <?php if($order->order_status == 0): ?>
                                                        <p>Pesanan diterima</p>
                                                    <?php elseif($order->order_status == 1): ?>
                                                        <p>Pesanan diproses</p>
                                                    <?php else: ?>
                                                        <p>Pesanan selesai</p>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <div class="text-right">
                                        <a href="<?php echo e(route('orders.details', ['orderID' => $order->id])); ?>"><button class="btn text-white" style="background-color: #7CA982">Lihat Detail</button></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Backup2\samudra-kue\resources\views/user/orders/index.blade.php ENDPATH**/ ?>