

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div>
                <div>
                    <h3 class="pt-5 pb-5">Detail Pesanan</h3>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="card-text mb-2">
                            <h6 class="d-inline">Nama Pelanggan : </h6>
                            <p class="d-inline"><?php echo e($order->user->username); ?></p>
                        </div>

                        <div class="card-text mb-2">
                            <h6 class="d-inline">Tanggal Pemesanan : </h6>
                            <p class="d-inline"><?php echo e($order->created_at); ?></p>
                        </div>

                        <div class="card-text mb-2">
                            <h6 class="d-inline">Alaman Pengantaran : </h6>
                            <p class="d-inline"><?php echo e($order->address->address); ?>, <?php echo e($order->address->postal_code); ?>, <?php echo e($order->address->kelurahan); ?>, <?php echo e($order->address->kecamatan); ?>, <?php echo e($order->address->city); ?>, <?php echo e($order->address->province); ?></p>
                        </div>
                    </div>
                </div>

                <div class="m-auto pt-3 table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">Nama Produk</th>
                                <th scope="col">Kuantitas</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($orderItem->product->product_name); ?></td>
                                    <td><?php echo e($orderItem->qty); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="card-text">
                            <h6 class="d-inline">Catatan Tambahan:</h6>
                            <p class="d-inline"><?php echo e($order->add_notes); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/admin/order/detailsOrder.blade.php ENDPATH**/ ?>