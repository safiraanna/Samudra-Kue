

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3 class="mt-5">Pesanan</h3>
                </div>

                <div class="m-auto pt-3 table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">ID Pesanan</th>
                                <th scope="col">Nama Pelanggan</th>
                                <th scope="col">Total Harga</th>
                                <th scope="col">Status Pembayaran</th>
                                <th scope="col">Status Pesanan</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->id); ?></td>
                                    <td><?php echo e($order->user ? $order->user->username : 'Tidak Ada User Terkait'); ?></td>
                                    <td><?php echo e($order->payment_total); ?></td>
                                    <td>
                                        <?php echo e($order->payment_status); ?>

                                        
                                    </td>
                                    <td>
                                        <?php echo e($order->order_status); ?>

                                        
                                    </td>
                                    <td>
                                        <div>
                                            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#updateStatusModal<?php echo e($order->id); ?>">
                                                Ubah Status
                                            </button>
                                        </div>
                                        <div class="mt-3">
                                            <a href="<?php echo e(route('details.orders', ['order' => $order->id])); ?>"><button type="button" class="btn btn-primary">Lihat Pesanan</button></a>
                                        </div>
                                    </td>
                                </tr>

                                <div class="modal fade" id="updateStatusModal<?php echo e($order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="updateStatusModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <form method="POST" action="<?php echo e(route('updateOrderStatus', $order->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="updateStatusModalLabel">Ubah Status Pesanan</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label for="order_status">Status Pesanan</label>
                                                        <select name="order_status" id="order_status" class="form-control">
                                                            
                                                            <option value="Pesanan sedang dikemas" <?php if($order->order_status == 'Pesanan sedang dikemas'): ?> selected <?php endif; ?>>Sedang Diproses</option>
                                                            <option value="Pesanan dalam pengantaran ke tujuan" <?php if($order->order_status == 'Pesanan sedang dikemas'): ?> selected <?php endif; ?>>Sedang Diantar</option>
                                                            <option value="Pesanan selesai" <?php if($order->order_status == 'Pesanan selesai'): ?> selected <?php endif; ?>>Pesanan Selesai</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/admin/order/order.blade.php ENDPATH**/ ?>