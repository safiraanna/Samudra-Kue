

<?php $__env->startSection('container'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="mt-3">
                    <h3 class="mt-3 text-center">Alamat Saya</h3>
                </div>

                <div class="col-md-d p-5">
                    <?php if($shippingAddress): ?>
                        <div class="card mt-3">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-3">
                                        <h5 class="card-title">Alamat : </h5>
                                    </div>
                                    <div class="col-8">
                                        <p class="card-text">
                                            <?php echo e($shippingAddress->address); ?>, <?php echo e($shippingAddress->kelurahan); ?>, <?php echo e($shippingAddress->kecamatan); ?>, <?php echo e($shippingAddress->city); ?>, <?php echo e($shippingAddress->province); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-3 text-center">
                            <a href="<?php echo e(route('addresses.edit', $shippingAddress)); ?>">
                                <button type="submit" class="btn text-white" style="background-color: #7CA982">+Edit Alamat</button>
                            </a>
                        </div>
                    <?php else: ?>
                        <p>Anda belum menyimpan alamat</p>
                        <div class="mt-3 text-center">
                            <a href="<?php echo e(route('addresses.create')); ?>">
                                <button type="submit" class="btn text-white" style="background-color: #7CA982">+Tambah Alamat</button>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <script>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
        </script>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/user/addresses/index.blade.php ENDPATH**/ ?>