

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="">
                <div class="">
                    <h3 class="mt-5 mb-3">Ubah Spesifikasi Produk</h3>
                </div>

                <div class="row">
                    <div class="card col-md-8 border-0">
                        <div class="card-body">
                            <form action="<?php echo e(route('products.update', $product)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
    
                                <div class="form-group mb-2">
                                    <label for="product_name">Nama Product</label>
                                    <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input type="text" class="form-control <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="product_name" id="product_name" value="<?php echo e($product->product_name); ?>">
                                </div>
    
                                <div class="form-group mb-2">
                                    <label for="price_unit">Harga Satuan Kotak/Renceng</label>
                                    <input type="text" class="form-control" name="price_unit" id="price_unit" value="<?php echo e($product->price_unit); ?>">
                                </div>

                                <div class="form-group mb-2">
                                    <label for="price_box_unit">Harga Satuan Dus</label>
                                    <input type="text" class="form-control" name="price_box_unit" id="price_box_unit" value="<?php echo e($product->price_box_unit); ?>">
                                </div>

                                <div class="form-group mb-2">
                                    <label for="unit_per_box">Jumlah Satuan Kotak/Renceng Per Dus</label>
                                    <input type="text" class="form-control" name="unit_per_box" id="unit_per_box" value="<?php echo e($product->unit_per_box); ?>">
                                </div>
    
                                <div class="form-group mb-2">
                                    <label for="stocks">Jumlah Ketersediaan Produk</label>
                                    <input type="text" class="form-control" name="stocks" id="stocks" value="<?php echo e($product->stocks); ?>">
                                </div>
    
                                <div class="form-group mb-2">
                                    <label for="description">Deskripsi</label>
                                    <textarea name="description" id="description" cols="10" rows="5" class="form-control"> <?php echo e($product->description); ?> </textarea>
                                </div>
    
                                <div class="form-group mb-2">
                                    <label for="images">Masukkan Gambar</label>
                                    <input type="file" class="form-control" name="images" id="images">
                                </div>
    
                                <button class="btn btn-block form-control mt-3 text-white" style="background-color: #30343f">Tambah</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>