

<?php $__env->startSection('container'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="">
                    <h3 class="mt-3 text-center mb-5">Checkout</h3> 
                </div>

                <div class="col-md-d">
                    <form action="<?php echo e(route('checkout.store')); ?>" method="POST" id="checkout-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>

                        <div class="form-group">
                            

                            <div>
                                <label for="address">Alamat Pengiriman :</label>
                                <?php if($shippingAddress): ?>
                                    <input type="hidden" name="address" id="address" class="form-control mt-1 mb-2" value="<?php echo e($shippingAddress->id); ?>">
                                    <p><?php echo e($shippingAddress->province); ?>, <?php echo e($shippingAddress->city); ?>, <?php echo e($shippingAddress->kecamatan); ?>, <?php echo e($shippingAddress->kelurahan); ?>, <?php echo e($shippingAddress->address); ?>, <?php echo e($shippingAddress->postal_code); ?></p>
                                <?php else: ?>
                                    <p>Tidak ada alamat yang tersedia</p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mt-3">
                                <div>
                                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cartItem->chosen == 1): ?>
                                            <input type="hidden" name="chosenProducts[]" value="<?php echo e($cartItem->product->id); ?>">
                                            <p><?php echo e($cartItem->product->product_name); ?> X <?php echo e($cartItem->qty); ?></p> 
                                            <p class="text-right">Subtotal : <?php echo e(number_format($cartItem->price_subtotal, 2, '.', ',')); ?></p>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <div>
                                    <label for="payment_method" style="display: inline">Metode Pembayaran</label>
                                    <select name="payment_method" id="payment_method" class="form-control mt-1" style="display: inline">
                                        <option value="online_payment">Pembayaran Online</option>
                                        <option value="cash_on_delivery">Bayar Tunai Saat Pengiriman</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mt-2 text-right">
                                <div>
                                    <label for="payment_total">Total Pesanan: Rp <?php echo e(number_format($total, 2, '.', ',')); ?></label>
                                    <input type="hidden" name="payment_total" value="<?php echo e($total); ?>">
                                </div>

                                <div>
                                    <label for="shipping_cost">Biaya Pengiriman: Rp <?php echo e(number_format($shippingCost, 2, '.', ',')); ?></label>
                                    <input type="hidden" name="shipping_cost" value="<?php echo e($shippingCost); ?>">
                                </div>
                            </div>

                            <div>
                                <label for="add_notes" class="mt-3">Catatan Tambahan </label>
                                <input type="text" id="add_notes" name="add_notes" class="form-control mt-1" placeholder="Tulis catatanmu disini...">
                            </div>
                        </div>                    
                    
                        <!-- Tombol Submit -->
                        <button type="submit" class="btn mt-3 text-white" id="checkout-button" style="background-color: #7CA982">+ Buat Pesanan</button>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </form> 
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/orders/checkout.blade.php ENDPATH**/ ?>