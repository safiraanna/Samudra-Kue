

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div>
                <h5 class="mb-3">Weekly Sales Report</h5>
                
                <p>Periode: <?php echo e($startDate->toDateString()); ?> - <?php echo e($endDate->toDateString()); ?></p>
                <p>Total Pemasukkan: Rp <?php echo e(number_format($totalRevenue, 2, '.', ',')); ?></p>
            </div>

            <div class="m-auto pt-3 table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">OrderID</th>
                            <th scope="col">UserID</th>
                            <th scope="col">Nama Produk</th>
                            <th scope="col">Total Terjual</th>
                            <th scope="col">Subtotal</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $weeklyDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($detail->orderID); ?></td>
                                <td><?php echo e($detail->userID); ?></td>
                                <td><?php echo e($detail->product_name); ?></td>
                                <td><?php echo e($detail->qty); ?></td>
                                <td>Rp <?php echo e(number_format($detail->price, 2, '.', ',')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/admin/report/details.blade.php ENDPATH**/ ?>