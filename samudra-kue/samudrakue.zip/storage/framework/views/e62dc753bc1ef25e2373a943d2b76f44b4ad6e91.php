

<?php $__env->startSection('container'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="">
                    <h3 class="mt-3 text-center mb-5">Detail Pesanan</h3> 
                </div>

                <div class="col-md-d">
                        <div class="form-group">
                            <div>
                                <label for="address">Alamat Pengiriman :</label>
                                <?php if($shippingAddress): ?>
                                    
                                    <p><?php echo e($shippingAddress->province); ?>, <?php echo e($shippingAddress->city); ?>, <?php echo e($shippingAddress->kecamatan); ?>, <?php echo e($shippingAddress->kelurahan); ?>, <?php echo e($shippingAddress->address); ?>, <?php echo e($shippingAddress->postal_code); ?></p>
                                <?php else: ?>
                                    <p>Tidak ada alamat yang tersedia</p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mt-3">
                                <div>
                                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cartItem->chosen === 1): ?>
                                            
                                            <p class="dollar"><?php echo e($cartItem->product->product_name); ?> X <?php echo e($cartItem->qty); ?></p> 
                                            <p class="text-right dollar">Subtotal : <?php echo e(number_format($cartItem->price_subtotal, 2, '.', ',')); ?></p>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <div class="mt-2 text-right">
                                <div>
                                    <label for="payment_total" class="dollar">Total Pesanan: Rp <?php echo e(number_format($payment_total, 2, '.', ',')); ?></label>
                                    
                                </div>

                                <div>
                                    <label for="shipping_cost">Biaya Pengiriman: <span  id="shipping_cost_display"></span></label>
                                    
                                </div>
                            </div>

                            <div>
                                <label for="add_notes" class="mt-3">Catatan Tambahan </label>
                                <input type="text" id="add_notes" name="add_notes" class="form-control mt-1" placeholder="Tulis catatanmu disini...">
                            </div>
                        </div>                    
                    
                        <!-- Tombol Submit -->
                        <button type="submit" class="btn mt-3 text-white" id="pay-button" style="background-color: #7CA982">Bayar Sekarang</button>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                </div>
            </div>
            
            <form action="" id="submit_form" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="json" id="json_callback">
            </form>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
        <script type="text/javascript" src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-udu3XJC0BvEB7YA3"></script>


        <script type="text/javascript">
                var payButton = document.getElementById('pay-button');
                payButton.addEventListener('click', function () {
                    window.snap.pay('<?php echo e($snapToken); ?>' , {
                        onSuccess: function (result) {
                            /* Implementasi ketika pembayaran berhasil */
                            // alert("Pembayaran berhasil!");
                            console.log(result);
                            send_response_to_form(result);
                        },
                        onPending: function (result) {
                            /* Implementasi ketika pembayaran masih tertunda */
                            // alert("Pembayaran masih tertunda");
                            console.log(result);
                            send_response_to_form(result);
                        },
                        onError: function (result) {
                            /* Implementasi ketika pembayaran gagal */
                            // alert("Pembayaran gagal!");
                            console.log(result);
                            send_response_to_form(result);
                        },
                        onClose: function () {
                            /* Implementasi ketika popup ditutup tanpa menyelesaikan pembayaran */
                            alert('Anda menutup popup tanpa menyelesaikan pembayaran');
                        }
                    })
                });

                function send_response_to_form(result) {
                    document.getElementById('json_callback').value = JSON.stringify(result);

                    alert(document.getElementById('json_callback').value);
                    $('#submit_form').submit();;
                }
        </script>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Backup2\samudra-kue\resources\views/orders/checkout.blade.php ENDPATH**/ ?>