

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div>
                <div>
                    <h3>Sales Report</h3>
                </div>

                <div>
                    <h5>Total Penjualan per Minggu</h5>

                    <div class="m-auto pt-3 table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Tahun</th>
                                    <th scope="col">Bulan</th>
                                    <th scope="col">Minggu</th>
                                    <th scope="col">Total Penjualan</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
    
                            <tbody>
                                <?php $__currentLoopData = $weeklySales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sales->year); ?></td>
                                        <td><?php echo e($sales->month); ?></td>
                                        <td><?php echo e($sales->week); ?></td>
                                        <td>Rp <?php echo e(number_format($sales->total_sales, 2, '.', ',')); ?></td>
                                        <td><a href="<?php echo e(route('weekly.sales.details', ['year' => $sales->year, 'month' => $sales->month, 'week' => $sales->week])); ?>">details</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <br><br>
    
                        <h5>Top 10 Produk Terlaris Minggu Ini</h5>

                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Nama Produk</th>
                                    <th scope="col">Total Terjual</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $bestProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->product->product_name); ?></td>
                                        <td><?php echo e($product->total_sold); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/admin/report/report.blade.php ENDPATH**/ ?>