

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Samudra Kue</title>

    <style>
        .custom-card {
            width: 12rem; /* Lebar kartu */
            height: 100%; 
        }

        .custom-card .card-title {
            font-size: 16px; /* Ubah ukuran teks sesuai preferensi Anda */
            color: #001A23
        }
    </style>
</head>

<?php $__env->startSection('container'); ?>
<body>
    <section>
        <div class="container text-center mt-5">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <h3 class="mb-4" style="color: #001A23">Cari Produk</h3>
                    <form>
                        <div class="form-group d-flex">
                            <input type="search" class="form-control form-control-lg mr-2" placeholder="Cari disini..." name="search" value="<?php echo e(request('search')); ?>" aria-label="Search">
                            <button class="btn btn-lg text-white" type="submit" style="background-color: #7CA982">Cari</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="row text-center">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-2 mt-5">
                <div class="card custom-card mb-3">
                    <a href="<?php echo e(url(sprintf('product/%s', $product->id))); ?>" class="text-decoration-none">
                        <?php if($product->images->isNotEmpty()): ?>
                            <img src="<?php echo e(asset('storage/product_images/' . $product->images[0]->picture_name)); ?>" class="card-img-top" alt="<?php echo e($product->product_name); ?>">
                        <?php else: ?>
                            <img src="https://source.unsplash.com/1000x500/?snack" alt="snack" class="card-img-top">
                        <?php endif; ?>
                        
                        <div class="card-body">
                            <h3 class="card-title" class="text-decoration-none fs-3"><?php echo e($product->product_name); ?></h3>
                        </div>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Backup2 - Copy\samudra-kue\resources\views/home.blade.php ENDPATH**/ ?>