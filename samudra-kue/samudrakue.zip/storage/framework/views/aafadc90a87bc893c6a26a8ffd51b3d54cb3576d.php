

<head>
    <?php if(session('error')): ?>
        <script>
            alert("<?php echo e(session('error')); ?>");
        </script>
    <?php endif; ?>
</head>

<?php $__env->startSection('container'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="mt-3">
                    <h3 class="mt-3 text-center">Keranjang Saya</h3>
                </div>

                <div class="col-md-d p-5">
                    <form action="<?php echo e(route('checkout.process')); ?>" method="POST" id="cart-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                    
                        <?php if($cartItems->isEmpty()): ?>
                            <p>Keranjang anda kosong! Ayo isi dulu</p>
                        <?php else: ?>
                            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card mt-3">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-1 mb-2">
                                                <input type="checkbox" class="form-check-input checkbox-chosen" data-product-id="<?php echo e($cartItem->product->id); ?>" name="chosen[]" value="<?php echo e($cartItem->product->id); ?>" />
                                            </div>
                                        </div>
                                        <div class="col-10">
                                            <h5 class="card-title"><?php echo e($cartItem->product->product_name); ?></h5>
                                        </div>
                                        <div class="col-1">
                                            <p class="card-text">x <?php echo e($cartItem->qty); ?></p>
                                        </div>
                                    </div>

                                    <div class="col-11 ml-5 text-right">
                                        <p class="card-text">Harga : <?php echo e(number_format($cartItem->product->price_unit, 2, '.', ',')); ?></p>
                                        <p class="card-text">Subtotal : <?php echo e(number_format($cartItem->price_subtotal, 2, '.', ',')); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <!-- Input hidden untuk produk yang dipilih -->
                        

                        <div class="mt-3 text-right">
                            <button type="submit" class="btn text-white" style="background-color: #7CA982" id="checkout-button">Checkout Sekarang</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Backup2 - Copy\samudra-kue\resources\views/carts/index.blade.php ENDPATH**/ ?>