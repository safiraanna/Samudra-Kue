

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h3 class="mt-5">Daftar Produk</h3> 
                </div>

                

                <div class="m-auto pt-3 table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">ID Product</th>
                                <th scope="col">Nama Produk</th>
                                <th scope="col">Stok</th>
                                <th scope="col">Harga Satuan</th>
                                <th scope="col">Harga Satuan dalam Dus</th>
                                <th scope="col">Satuan per Dus</th>
                                <th scope="col">Deskripsi</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product->id); ?></td>
                                    <td><?php echo e($product->product_name); ?></td>
                                    <td><?php echo e($product->stocks); ?></td>
                                    <td><?php echo e($product->price_unit); ?></td>
                                    <td><?php echo e($product->price_box_unit); ?></td>
                                    <td><?php echo e($product->unit_per_box); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('products.destroy', $product)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger" type="submit">Delete</button>
                                        </form>

                                        <br>
                                        
                                        <form action="<?php echo e(route('products.edit', $product)); ?>" method="GET">
                                            <button class="btn btn-primary" type="submit">Edit</button>
                                        </form>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="d-flex justify-content-center mt-4">
                        <?php if($products->previousPageUrl()): ?>
                            <a href="<?php echo e($products->previousPageUrl()); ?>" class="btn btn-primary" rel="prev">&lt;</a>
                        <?php endif; ?>
                        
                        <?php if($products->nextPageUrl()): ?>
                            <a href="<?php echo e($products->nextPageUrl()); ?>" class="btn btn-primary ml-3" rel="next">&gt;</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/admin/product/index.blade.php ENDPATH**/ ?>