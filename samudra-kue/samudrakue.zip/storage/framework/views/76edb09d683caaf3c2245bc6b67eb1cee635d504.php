

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h3 class="mt-5">Daftar Pengguna</h3>
                </div>

                <div class="m-auto pt-3 table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">ID Pengguna</th>
                                <th scope="col">Username</th>
                                <th scope="col">Nama Pelanggan</th>
                                <th scope="col">Nomor Telepon</th>
                                <th scope="col">Jumlah Pesanan</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->username); ?></td>
                                    <td><?php echo e($user->full_name); ?></td>
                                    <td><?php echo e($user->phone_number); ?></td>
                                    <td><?php echo e($user->orders->count()); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/admin/user/users.blade.php ENDPATH**/ ?>