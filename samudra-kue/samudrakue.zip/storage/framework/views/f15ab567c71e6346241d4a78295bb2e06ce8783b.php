

<head>
    <style>
        /* Warna latar belakang dan warna ikon */
        .carousel-control-prev, .carousel-control-next {
            background-color: #f1f7ed;
            opacity: 20%;
        }
    
        /* Warna ikon */
        .carousel-control-prev-icon, .carousel-control-next-icon {
            color: #7CA982;
        }

        .carousel-item img {
        width: 100%;
        max-height: 360px; 
        object-fit: scale-down;
        }
    </style>

    <script>
        <?php if(session('error')): ?>
            alert("<?php echo e(session('error')); ?>");
        <?php endif; ?>
    </script>
</head>

<?php $__env->startSection('container'); ?>
    <section>
        <div>
            <div class="container mt-5"> 
                <div class="row">
                    <div class="col-md-6">
                        <div id="imageCarousel" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li data-target="#imageCarousel" data-slide-to="<?php echo e($key); ?>" class="<?php echo e($key == 0 ? 'active' : ''); ?>"></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                            <div class="carousel-inner">
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                                        <img src="<?php echo e(asset('storage/product_images/' . $image->picture_name)); ?>" class="d-block w-100" alt="<?php echo e($product->product_name); ?>">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <a class="carousel-control-prev" href="#imageCarousel" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#imageCarousel" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h2 class="card-title"><?php echo e($product->product_name); ?></h2>
                                <h6 class="card-text mt-5">Harga Kotak : Rp <?php echo e(number_format($product->price_unit, 2, '.', ',')); ?></h6>
                                <h6 class="card-text mt-3">Isi per Dus : <?php echo e($product->unit_per_box); ?> kotak</h6>
                                <h6 class="card-text mt-3">Tersedia <?php echo e($product->stocks); ?> buah</h6></label>

                                <form action="<?php echo e(route('add_to_cart', ['id' => $product->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <label for="quantity">Jumlah:</label>
                                        <input type="number" class="form-control mt-3" name="quantity" id="quantity" value="1" min="1" max="<?php echo e($product->stocks); ?>">
                                    </div>
                                    <button type="submit" class="btn mt-3 text-white" style="background-color: #7CA982">+ Tambah ke Keranjang</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>  
                
                <div class="col-md-12 mt-3">
                    <div class="card" >
                        <div class="card-body">
                            <p class="m-2"><?php echo nl2br(e($product->description)); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/products/product.blade.php ENDPATH**/ ?>