

<?php $__env->startSection('container'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="mt-3">
                    <h3 class="mt-3 text-center">Pesanan Saya</h3>
                </div>

                <div class="col-md-d p-5" >
                    <?php if($orders->isEmpty()): ?>
                        <p>Anda belum membuat pesanan apapun</p>
                    <?php else: ?>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($order->payment_method == 'cash_on_delivery'): ?>
                                <div class="card mt-3">
                                    <div class="card-body">
                                        <div class="card-text">
                                            <div class="">
                                                <h5 class="d-inline">Pesanan <?php echo e($index + 1); ?> : </h5>
                                                
        
                                                <div class="d-inline text-right">
                                                    <button class="btn text-dark" style="background-color: #fafafa">
                                                        <p><?php echo e($order->order_status); ?></p>
                                                    </button>
                                                </div>
                                            </div>
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?> 
                                <div class="card mt-3">
                                    <div class="card-body">
                                        <div class="card-text">
                                            <div class="">
                                                <h5 class="d-inline">Pesanan <?php echo e($index + 1); ?> : </h5>
                                                

                                                <div class="d-inline text-right">
                                                    <button class="btn text-dark" style="background-color: #fafafa">
                                                        <?php if($order->payment_status == 0): ?> 
                                                            <p>Menunggu Pembayaran</p>
                                                        <?php else: ?>
                                                            <p><?php echo e($order->payment_status); ?></p>
                                                        <?php endif; ?>
                                                    </button>
                                                </div>
                                            </div>
                                            
                                            <div class="text-right">
                                                <a href="<?php echo e(route('orders.details', ['orderID' => $order->id])); ?>"><button class="btn text-white" style="background-color: #7CA982">Lihat Detail</button></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Backup2 - Copy\samudra-kue\resources\views/user/orders/index.blade.php ENDPATH**/ ?>