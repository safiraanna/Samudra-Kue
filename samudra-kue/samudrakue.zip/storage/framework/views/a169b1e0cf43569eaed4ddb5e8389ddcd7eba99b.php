

<?php $__env->startSection('container'); ?>
    <section>
        <div class="container">
            <div>
                <div>
                    <h3 class="pt-5 pb-5">Detail Pesanan</h3>
                </div>

                

                <div>
                    <form action="<?php echo e(route('payment.process', ['orderID' => $order->id])); ?>" method="POST" id="payment-process">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>

                        <div class="mb-2">
                            <h6 class="d-inline">Status Pesanan : </h6>
                            <span><?php echo e($order->order_status); ?></span>
        
                            
                        </div>  
        
                        <div class="card">
                            <div class="card-body">
                                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p style="font-weight: 500"><?php echo e($orderItem->product->product_name); ?> X <?php echo e($orderItem->qty); ?></p>
                                    <p class="text-right">Rp<?php echo e(number_format($orderItem->price, 2, '.', ',')); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
        
                            <div class="card-body text-right">
                                <p>Biaya Pengiriman : Rp<?php echo e(number_format($order->shipping_cost, 2, '.', ',')); ?></p>
                                <p>Total Pembayaran : Rp<?php echo e(number_format($order->payment_total + $order->shipping_cost, 2, '.', ',')); ?> </p>
                            </div>
                        </div>
        
                        <div class="card mt-3">
                            <div class="card-body">
                                <div class="card-text">
                                    <h6 class="d-inline">Catatan Tambahan:</h6>
                                    <p class="d-inline"><?php echo e($order->add_notes); ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <?php if($order->payment_method !== 'cash_on_delivery'): ?>
                            <button type="submit" class="btn mt-3 text-white" id="checkout-button" style="background-color: #7CA982">Bayar Sekarang</button>
                        <?php endif; ?>
                    </form>
                </div>
                            
                
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Materi Matkul\Semester 7\Skripsi\Develop - Use\samudra-kue\resources\views/user/orders/details.blade.php ENDPATH**/ ?>